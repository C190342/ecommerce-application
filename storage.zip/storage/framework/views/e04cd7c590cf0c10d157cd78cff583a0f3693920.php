
<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('content'); ?>
    <!-- ========================= SECTION CONTENT ========================= -->
    <section class="section-content padding-y">
        <div class="container">


        <!-- ============================  FILTER TOP  ================================= -->
            <div class="card mb-3">
                <div class="card-body">
                    <ol class="breadcrumb float-left">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">All Category</a></li>
                        <li class="breadcrumb-item active"><?php echo e($category->name); ?></li>
                    </ol>
                </div> <!-- card-body .// -->
            </div> <!-- card.// -->
            <!-- ============================ FILTER TOP END.// ================================= -->

            <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3">
                    <figure class="card card-product-grid">
                        <div class="img-wrap"> 
                            <span class="badge badge-danger"> NEW </span>
                            <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                            <?php if($product->images->count() > 0): ?>
                                <img src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>" alt="">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/176" alt="">
                            <?php endif; ?>
                            </a>
                        </div> <!-- img-wrap.// -->
                        <figcaption class="info-wrap">
                                <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="title mb-2 h5"><?php echo e($product->name); ?></a>
                                <div class="price-wrap">
                                <?php if($product->sale_price != 0): ?>
                                    
                                    <span class="price"> <?php echo e(config('settings.currency_symbol').$product->sale_price); ?> </span>
                                    <small class="text-muted">/per bag</small>
                                    <del class="price-old"> <?php echo e(config('settings.currency_symbol').$product->price); ?></del>
                                    
                                <?php else: ?>
                                    
                                    <span class="price"> <?php echo e(config('settings.currency_symbol').$product->price); ?> </span>
                                    <small class="text-muted">/per bag</small>
                                    
                                <?php endif; ?> 
                                </div> <!-- price-wrap.// -->
                                
                                <p class="mb-2"> 2 Pieces  <small class="text-muted">(Min Order)</small></p>
                                
                                <p class="text-muted "><?php echo e(Str::words($product->description,20)); ?></p>
                            
                                <hr>
                                
                                <p class="mb-3">
                                    <span class="tag"> <i class="fa fa-check"></i> Verified</span> 
                                    <span class="tag"> 4 Years </span> 
                                    <span class="tag"> 60 reviews </span>
                                    <span class="tag"> China </span>
                                </p>
                            
                                <label class="custom-control mb-3 custom-checkbox">
                                <input type="checkbox" class="custom-control-input">
                                <div class="custom-control-label">Add to compare
                                </div>
                                </label>

                                <a href="#" class="btn btn-outline-primary"> <i class="fa fa-envelope"></i> Contact supplier </a>	
                                
                        </figcaption>
                    </figure>
                </div> <!-- col.// -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="mb-3 col-md-4">
                    <p>No Products found in <?php echo e($category->name); ?>.</p>
                </div>
            <?php endif; ?>
            </div> <!-- row end.// -->

            <div class="row">
                <nav class="mb-3 col-md-4" aria-label="Page navigation sample">
                    <ul class="pagination">
                        <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div> <!-- row end.// -->

        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/category1.blade.php ENDPATH**/ ?>