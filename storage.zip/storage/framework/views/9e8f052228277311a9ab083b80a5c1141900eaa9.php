<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/images/faviconbook.ico')); ?>">
<link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.theme.default.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/ui.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" /><?php /**PATH D:\Working\PHP\xampp\htdocs\ecommerce-application\resources\views/site/partials/styles.blade.php ENDPATH**/ ?>