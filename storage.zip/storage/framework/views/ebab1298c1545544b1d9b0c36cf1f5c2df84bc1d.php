<?php if(Session::has('message')): ?>
	<p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
<?php if(Session::has('error')): ?>
	<p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>
<div class="card-body">
	
	<!-- form change pw -->
	<form id="form-pw" action="<?php echo e(route('account.profile.changepw')); ?>" method="post" class="row" >
		<h4>Change Password</h4>
		<?php echo csrf_field(); ?>
		<div class="col-md-12">
			<div class="form-row mb-3">
				
				<div class="col-md-4">
					<div class="form-group mt-3">
						<label for="current_password">Old password</label>
						<input type="password" name="current_password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
							placeholder="Enter current password" autocomplete="off">
						<?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group mt-3">
						<label for="new_password ">new password</label>
						<input autocomplete="off" type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
							placeholder="Enter the new password">
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group mt-3">
						<label for="confirm_password">confirm password</label>
						<input autocomplete="off" type="password" name="confirm_password" class="form-control <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"required placeholder="Enter same password">
						<?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="d-flex justify-content-first mt-4 ml-2">
					<button type="submit" class="btn btn-primary"
						id="formSubmit">change password</button>
				</div>
			</div>
		</div>    
    </form>
</div><!-- card-body.// --><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/includes/change.blade.php ENDPATH**/ ?>