<aside class="col-md-3">
    <nav class="list-group">
        <a class="list-group-item <?php echo e(Route::currentRouteName() == 'account.profile' ? 'active' : ''); ?>" href="<?php echo e(route('account.profile')); ?>"> Account overview  </a>
        <a class="list-group-item <?php echo e(Route::currentRouteName() == 'account.changepw' ? 'active' : ''); ?>" href="<?php echo e(route('account.changepw')); ?>"> Change Password </a>
        <a class="list-group-item <?php echo e(Route::currentRouteName() == 'account.address' ? 'active' : ''); ?>" href="<?php echo e(route('account.address')); ?>"> My Address </a>
        <a class="list-group-item <?php echo e(Route::currentRouteName() == 'account.orders' ? 'active' : ''); ?>" href="<?php echo e(route('account.orders')); ?>"> My Orders </a>
        <a class="list-group-item <?php echo e(Route::currentRouteName() == 'account.wishlist' ? 'active' : ''); ?>" href="<?php echo e(route('account.wishlist')); ?>"> My Wishlist </a>
        <a class="list-group-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                        document.getElementById('logout-form2').submit();"><i class="fas fa-sign-out-alt"></i> 
            <?php echo e(__('Logout')); ?>

        </a>
        <form id="logout-form2" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </nav>
</aside> <!-- col.// --><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/partials/profile_sidebar.blade.php ENDPATH**/ ?>