
<?php $__env->startSection('title', $profile->last_name."'s Profile"); ?>
<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION PAGETOP ========================= -->
<section class="section-pagetop bg-gray">
<div class="container">
	<h2 class="title-page">My account</h2>
</div> <!-- container //  -->
</section>
<!-- ========================= SECTION PAGETOP END// ========================= -->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
<div class="container">

    <div class="row">
        <?php echo $__env->make('site.partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="col-md-9 tab-content">

        <?php if(Session::has('message')): ?>
            <p class="col-md-12 alert alert-success"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <p class="col-md-12 alert alert-danger"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form class="row" id="form-profile" action="<?php echo e(route('account.profile.update')); ?>" method="POST" role="form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-9">
                            
                            <div class="form-row">
                                <div class="col form-group">
                                    <label>First Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" id="first_name" value="<?php echo e($profile->first_name); ?>">
                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- form-group end.// -->
                                <div class="col form-group">
                                    <label>Last Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" id="last_name" value="<?php echo e($profile->last_name); ?>">
                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- form-group end.// -->
                            </div> <!-- form-row.// -->

                            <div class="form-row">
                                <div class="col form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" value="<?php echo e($profile->email); ?>" readonly>
                                    
                                </div> <!-- form-group end.// -->
                                <div class="col form-group">
                                    <label>Avatar</label>
                                    <input type="file" class="form-control <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="avatar" id="avatar" value="<?php echo e($profile->avatar); ?>">
                                    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- form-group end.// -->
                            </div> <!-- form-row.// -->

                            <div class="form-row">
                                <div class="col form-group">
                                    <label>Address</label>
                                        <input type="text" class="form-control" name="address" id="address" value="<?php echo e($profile->address); ?>">
                                </div> <!-- form-group end.// -->
                            </div> <!-- form-row.// -->
                            
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Country</label>
                                    <select id="country" name="country" class="form-control">
                                        <?php 
                                        $countries = array(
                                            "CN" => "China",
                                            "JP" => "Japan",
                                            "KR" => "Korea, Republic of",
                                            "SG" => "Singapore",
                                            "TW" => "Taiwan, Province of China",
                                            "US" => "United States",
                                            "VN" => "Viet Nam");
                                        ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($key == $profile->country): ?>
                                                <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($key); ?>" ><?php echo e($value); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div> <!-- form-group end.// -->
                                <div class="form-group col-md-6">
                                <label>City</label>
                                <input type="text" class="form-control" name="city" id="city" value="<?php echo e($profile->city); ?>">
                                </div> <!-- form-group end.// -->
                            </div> <!-- form-row.// -->

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                <label>Zip</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="zip" id="zip" value="<?php echo e($profile->zip); ?>">
                                    <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- form-group end.// -->
                                <div class="form-group col-md-6">
                                <label>Phone</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" id="phone" value="<?php echo e($profile->phone); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- form-group end.// -->
                            </div> <!-- form-row.// -->

                            <button class="btn btn-primary" type="submit" >Save</button>

                            

                        </div> <!-- col.// -->
                        <div class="col-md">
                            <?php if($profile->avatar != ''): ?>
                                <img src="<?php echo e(asset('storage/'.$profile->avatar)); ?>" class="img-md rounded-circle border">
                            <?php else: ?>
                                <img class="img-md rounded-circle border" src="https://via.placeholder.com/176" style="height: 150px; width: 150px;">
                            <?php endif; ?>

                        </div>  <!-- col.// -->
                    </form>

                </div><!-- card-body.// -->
            </div> <!-- card .// -->

	    </main> <!-- col.// -->
            
        
    </div>

    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/index.blade.php ENDPATH**/ ?>