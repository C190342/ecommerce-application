<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/images/HmAJlUwZXDjxcS1hRjgILGpTq.png')); ?>">
<link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.theme.default.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/ui.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1140px)" />

<?php echo $__env->yieldPushContent('styles'); ?>
<!-- Font awesome 5 -->
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/all.min.css')); ?>" type="text/css" rel="stylesheet">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/partials/styles.blade.php ENDPATH**/ ?>