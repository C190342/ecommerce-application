
<?php $__env->startSection('title', $profile->last_name."'s Profile"); ?>
<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION PAGETOP ========================= -->
<section class="section-pagetop bg-gray">
<div class="container">
	<h2 class="title-page">My account</h2>
</div> <!-- container //  -->
</section>
<!-- ========================= SECTION PAGETOP END// ========================= -->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
<div class="container">

    <div class="row">
        <aside class="col-md-3">
            <nav class="list-group">
                <a class="list-group-item active" href="#general" data-toggle="tab"> Account overview  </a>
                <a class="list-group-item" href="#address" data-toggle="tab"> My Address </a>
                <a class="list-group-item" href="#orders" data-toggle="tab"> My Orders </a>
                <a class="list-group-item" href="#wishlist" data-toggle="tab"> My Wishlist </a>
                <a class="list-group-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> 
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </nav>
        </aside> <!-- col.// -->

        <main class="col-md-9 tab-content">

            <div class="card tab-pane active" id="general">
                <?php echo $__env->make('site.pages.account.includes.setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- card .// -->
            <div class="tab-pane" id="address">
                <?php echo $__env->make('site.pages.account.includes.address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- card .// -->
            <div class="tab-pane" id="orders">
                <?php echo $__env->make('site.pages.account.includes.orders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- card .// -->
            <div class="tab-pane" id="wishlist">
                <?php echo $__env->make('site.pages.account.includes.wishlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- card .// -->



	    </main> <!-- col.// -->
            
        
    </div>

    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/setting.blade.php ENDPATH**/ ?>