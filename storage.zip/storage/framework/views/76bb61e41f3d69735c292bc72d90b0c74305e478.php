<header class="section-header">
<section class="header-main border-bottom">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-xl-2 col-lg-3 col-md-12">
				<a href="<?php echo e(url('/')); ?>" class="brand-wrap">
					<img class="logo" src="<?php echo e(asset('frontend/images/logo1.png')); ?>">
				</a> <!-- brand-wrap.// -->
			</div>
			<div class="col-xl-6 col-lg-5 col-md-6">
				<form action="#" class="search-header">
					<div class="input-group w-100">
						<select class="custom-select border-right"  name="category_name">
								<option value="">All type</option><option value="codex">Special</option>
								<option value="comments">Only best</option>
								<option value="content">Latest</option>
						</select>
					    <input type="text" class="form-control" placeholder="Search">
					    
					    <div class="input-group-append">
<!--
							<button class="btn btn-primary" type="submit">
								<i class="fa fa-search"></i> Search
							</button>
-->
							<a class="btn btn-primary" href="<?php echo e(url('/search/1')); ?>">
								<i class="fa fa-search"></i> Search
							</a>
					    </div>
				    </div>
				</form> <!-- search-wrap .end// -->
			</div> <!-- col.// -->
			<div class="col-xl-4 col-lg-4 col-md-6">
				<div class="widgets-wrap float-md-right">
                    
					<div class="widget-header mr-3">
                        <?php if(auth()->guard()->guest()): ?>
                            <ul class="navbar-nav ml-auto widget-view no-top">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <div class="icon-area">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <small class="text"> Guest </small>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> Login</a>
                                        <a class="dropdown-item" href="<?php echo e(route('register')); ?>"><i class="fas fa-user-edit"></i> Register</a>
                                    </div>
                                </li>
                            </ul>
                        <?php else: ?>
                            <ul class="navbar-nav ml-auto widget-view no-top">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <div class="icon-area">
                                            <i class="fa fa-user"></i>
                                        </div>
							            <small class="text"> My profile </small>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('account.profile')); ?>"><i class="fas fa-address-card"></i> Edit Profile</a>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> 
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            </ul>
                        <?php endif; ?>
					</div>
					
					<div class="widget-header mr-3">
						<a href="#" class="widget-view">
							<div class="icon-area">
								<i class="fa fa-comment-dots"></i>
								<span class="notify">0</span>
							</div>
							<small class="text"> Message </small>
						</a>
					</div>

					<div class="widget-header mr-3">
						<a href="<?php echo e(route('account.orders')); ?>" class="widget-view">
							<div class="icon-area">
								<i class="fa fa-store"></i>
								<span class="notify"><?php echo e($orderCount); ?></span>
							</div>
							<small class="text"> Orders </small>
						</a>
					</div>

					<div class="widget-header">
						<a href="<?php echo e(route('checkout.cart')); ?>" class="widget-view">
							<div class="icon-area">
								<i class="fa fa-shopping-cart"></i>
								<span class="notify"><?php echo e($cartCount); ?></span>
							</div>
							<small class="text"> Cart </small>
						</a>
					</div>

				</div> <!-- widgets-wrap.// -->
			</div> <!-- col.// -->
		</div> <!-- row.// -->
	</div> <!-- container.// -->
</section> <!-- header-main .// -->


    <?php echo $__env->make('site.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/partials/header.blade.php ENDPATH**/ ?>