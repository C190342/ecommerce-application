
<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Homepage</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working\PHP\xampp\htdocs\ecommerce-application\resources\views/site/pages/homepage.blade.php ENDPATH**/ ?>