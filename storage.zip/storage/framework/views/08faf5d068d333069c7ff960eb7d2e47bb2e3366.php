<?php if(Session::has('message')): ?>
	<p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
<?php if(Session::has('error')): ?>
	<p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>
<div class="card-body">
	<h1>Hello</h1>

</div><!-- card-body.// --><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/includes/setting1.blade.php ENDPATH**/ ?>