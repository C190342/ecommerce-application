
<?php $__env->startSection('title', 'Address List'); ?>
<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION PAGETOP ========================= -->
<section class="section-pagetop bg-gray">
<div class="container">
	<h2 class="title-page">My account</h2>
</div> <!-- container //  -->
</section>
<!-- ========================= SECTION PAGETOP END// ========================= -->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
<div class="container">

    <div class="row">
        <?php echo $__env->make('site.partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="col-md-9 tab-content">

        <?php if(Session::has('message')): ?>
            <p class="col-md-12 alert alert-success"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <p class="col-md-12 alert alert-danger"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>

            <a href="#" class="btn btn-light mb-3"> <i class="fa fa-plus"></i> Add new address </a>

            <div class="row">
                <div class="col-md-6">
                    <article class="box mb-4">
                        <h6>London, United Kingdom</h6>
                        <p>Building: Nestone <br> Floor: 22, Aprt: 12  </p>
                        <a href="#" class="btn btn-light disabled"> <i class="fa fa-check"></i> Default</a> <a href="#" class="btn btn-light"> <i class="fa fa-pen"></i> </a>   <a href="#" class="btn btn-light"> <i class="text-danger fa fa-trash"></i>  </a>
                    </article>
                </div>  <!-- col.// -->
                <div class="col-md-6">
                    <article class="box mb-4">
                        <h6>Tashkent, Uzbekistan</h6>
                        <p>Building one <br> Floor: 2, Aprt: 32  </p>
                        <a href="#" class="btn btn-light">Make default</a> <a href="#" class="btn btn-light"> <i class="fa fa-pen"></i> </a>   <a href="#" class="btn btn-light"> <i class="text-danger fa fa-trash"></i>  </a>
                    </article>
                </div>  <!-- col.// -->
                <div class="col-md-6">
                    <article class="box mb-4">
                        <h6>Moscow, Russia</h6>
                        <p>Lenin street <br> Building A, Floor: 3, Aprt: 32  </p>
                        <a href="#" class="btn btn-light">Make default</a> <a href="#" class="btn btn-light"> <i class="fa fa-pen"></i> </a>   <a href="#" class="btn btn-light"> <i class="text-danger fa fa-trash"></i>  </a>
                    </article>
                </div>  <!-- col.// -->
            </div> <!-- row.// -->

	    </main> <!-- col.// -->
            
        
    </div>

    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/address.blade.php ENDPATH**/ ?>