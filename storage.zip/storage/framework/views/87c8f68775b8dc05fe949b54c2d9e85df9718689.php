
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION PAGETOP ========================= -->
<section class="section-pagetop bg-gray">
<div class="container">
	<h2 class="title-page">My account</h2>
</div> <!-- container //  -->
</section>
<!-- ========================= SECTION PAGETOP END// ========================= -->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
    <div class="container">

        <div class="row">
            <?php echo $__env->make('site.partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="col-md-9 tab-content">

            <?php if(Session::has('message')): ?>
                <p class="col-md-12 alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
                <p class="col-md-12 alert alert-danger"><?php echo e(Session::get('error')); ?></p>
            <?php endif; ?>
			
			<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div id="<?php echo e($order->order_number); ?>">
				<article class="card mb-4 print-tab" > 
					<header class="card-header">
						<button class="float-right hidden-print" ><i class="fa fa-print"></i></button>
						<strong class="d-inline-block mr-3">Order ID: <?php echo e($order->order_number); ?></strong>
						<span>Order Date: <?php echo e($order->created_at->format('Y/m/d H:i:s')); ?></span>
					</header>
					<div class="card-body">
						<div class="row print-position"> 
							<div class="col-md-8 print-left">
								<h6 class="text-muted">Delivery to</h6>
								<p>Full name: <?php echo e($order->last_name); ?> <?php echo e($order->first_name); ?> <br>  
								Phone: <?php echo e($order->phone_number); ?> <br>
								Location: <?php echo e($order->address); ?>, <?php echo e($order->city); ?> <br> 
								Country: <?php echo e($order->country); ?> -- P.O. Box: <?php echo e($order->post_code); ?>

								</p>
							</div>
							<div class="col-md-4 print-right">
								<h6 class="text-muted">Payment</h6>
								<span class="text-success">
									<i class="fab fa-lg fa-cc-visa"></i>
									Visa  **** 4216  
								</span>
								<p>Subtotal: <?php echo e(config('settings.currency_symbol')); ?>356 <br>
								Shipping fee:  <?php echo e(config('settings.currency_symbol')); ?>56 <br> 
								<span class="b">Total: <?php echo e(config('settings.currency_symbol')); ?><?php echo e($order->grand_total); ?> </span><br>
								Payment Status: <span class="b"><?php if($order->payment_status == 1): ?> <span class="text-success">Completed</span> <?php else: ?> <span class="text-danger">Not Complete</span> <?php endif; ?> </span><br>
								Order Status: <span class="b"><?php if($order->status == 'completed'): ?> <span class="text-success"><?php echo e(ucfirst($order->status)); ?></span> <?php else: ?> <span class="primary-style"><?php echo e(ucfirst($order->status)); ?></span> <?php endif; ?> </span><br>
								</p>
							</div>
							<div class="clearfix"></div>
							<?php if($order->notes != ''): ?>
							<p class="col-md-12 hr"><span class="b">Note:</span> <?php echo e($order->notes); ?></p>
							<?php endif; ?>
						</div> <!-- row.// -->
					</div> <!-- card-body .// -->
					<div class="table-responsive">
						<table class="table table-hover">
							<tbody>
								<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<tr>
									<td width="65">
										<?php if($item->product->images->count() > 0): ?>
										<img src="<?php echo e(asset('storage/'.$item->product->images->first()->full)); ?>" class="img-xs border">
										<?php else: ?>
										<img src="https://via.placeholder.com/176" class="img-xs border">
										<?php endif; ?>
									</td>
									<td> 
										<p class="title mb-0"><span class="b"><?php echo e(Str::words($item->product->name,20)); ?> </span></p>
										<var class="price text-muted"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(round(($item->price/$item->quantity), 2)); ?></var>
										
									</td>
									<td class="text-center"> Quantity <br> <?php echo e($item->quantity); ?> </td>
									<td width="250"> <a href="#" class="btn btn-outline-primary">Track order</a> 
										<div class="dropdown d-inline-block">
											<a href="#" data-toggle="dropdown" class="dropdown-toggle btn btn-outline-secondary">More</a>
											<div class="dropdown-menu dropdown-menu-right">
												<a href="#" class="dropdown-item">Return</a>
												<a href="#"  class="dropdown-item">Cancel order</a>
											</div>
										</div> <!-- dropdown.// -->
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div> <!-- table-responsive .end// -->
				</article> <!-- card order-item .// -->
			</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="row">
				<p class="col-md-12 alert alert-warning mb-4">No orders to display.</p>
			
				<a href="#" class="btn btn-light mr-3"> <i class="fa fa-shopping-cart"></i> Got to cart </a>

				<a href="#" class="btn btn-light "> <i class="fas fa-cart-plus"></i> Start to shopping </a>
			</div>
			<?php endif; ?>
		

            </main> <!-- col.// -->
            
        
        </div>

    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('frontend/css/print.css')); ?>" rel="stylesheet" type="text/css" media="print" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('frontend/js/jQuery.print.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(function($) { 'use strict';
		
		$("button.hidden-print").click(function(e){
			var parentTag = $(this).parent().parent().parent().attr('id');
			let iddiv = "#".concat(parentTag);

			//Print ele2 with default options
			$.print(iddiv);
		});
	});
	
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-application\resources\views/site/pages/account/orders.blade.php ENDPATH**/ ?>